import torch
import torch.nn as nn

# define the CNN architecture
class MyModel(nn.Module):
    def __init__(self, num_classes: int = 1000, dropout: float = 0.7) -> None:

        super().__init__()

        # YOUR CODE HERE
        # Define a CNN architecture. Remember to use the variable num_classes
        # to size appropriately the output of your classifier, and if you use
        # the Dropout layer, use the variable "dropout" to indicate how much
        # to use (like nn.Dropout(p=dropout))

        self.conv_bb = nn.Sequential(
            
            # Convolutional Layer 1: 3*224*224 -> 8*112*112
            nn.Conv2d(in_channels=3, out_channels=8, kernel_size=3, padding=1), 
            nn.ReLU(),
            nn.MaxPool2d(2,2),
            
            # Convolutional Layer 2: 8*112*112 -> 16*56*56
            nn.Conv2d(in_channels=8, out_channels=16, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2,2),
            nn.BatchNorm2d(16),
            
            # Convolutional Layer 3: 16*56*56 -> 32*28*28
            nn.Conv2d(in_channels=16, out_channels=32, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2,2),
            nn.BatchNorm2d(32),
            
            # Convolutional Layer 4: 32*28*28 -> 48*14*14
            nn.Conv2d(in_channels=32, out_channels=48, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2,2),
            nn.BatchNorm2d(48),

            # Convolutional Layer 5: 48*14*14 -> 64*7*7
            nn.Conv2d(in_channels=48, out_channels=64, kernel_size=3, padding=1),
            nn.ReLU(),
            nn.MaxPool2d(2,2),
            nn.BatchNorm2d(64),
            
            # Flatten for Head input: 64*7*7 -> 1*3136
            nn.Flatten(),
        )

        self.mlp_head = nn.Sequential(
            # Linear Layer 1: 3136 -> 512
            nn.Linear(64*7*7, 512),
            nn.ReLU(),
            nn.Dropout(p=dropout),
            nn.BatchNorm1d(512),

            # Linear Layer 2: 512 -> 128
            nn.Linear(512, 128),
            nn.ReLU(),
            nn.Dropout(p=dropout),
            nn.BatchNorm1d(128),

            # Linear Layer 3: 128 -> num_classes
            nn.Linear(128, num_classes)
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # YOUR CODE HERE: process the input tensor through the
        # feature extractor, the pooling and the final linear
        # layers (if appropriate for the architecture chosen)
        x = self.conv_bb(x)
        x = self.mlp_head(x)
        return x


######################################################################################
#                                     TESTS
######################################################################################
import pytest

@pytest.fixture(scope="session")
def data_loaders():
    from .data import get_data_loaders

    return get_data_loaders(batch_size=2)


def test_model_construction(data_loaders):

    model = MyModel(num_classes=23, dropout=0.3)

    dataiter = iter(data_loaders["train"])
    images, labels = next(dataiter)

    out = model(images)

    assert isinstance(
        out, torch.Tensor
    ), "The output of the .forward method should be a Tensor of size ([batch_size], [n_classes])"

    assert out.shape == torch.Size(
        [2, 23]
    ), f"Expected an output tensor of size (2, 23), got {out.shape}"
